这是一个私钥文件，不包含证书和公钥。
This is a private key file and does not contain certificates or public keys.